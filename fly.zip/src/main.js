import './assets/scss/main.scss'

import './assets/js/lax-items.js'
import './assets/js/auto-grid.js'
import './assets/js/burger.js'
import './assets/js/common.js'
